package com.example.news_crawler_ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsCrawlerUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsCrawlerUiApplication.class, args);
	}

}
