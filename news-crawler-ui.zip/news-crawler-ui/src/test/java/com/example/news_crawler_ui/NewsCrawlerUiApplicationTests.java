package com.example.news_crawler_ui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsCrawlerUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
